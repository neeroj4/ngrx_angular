import { createAction, props } from '@ngrx/store';

export const increment = createAction('[Counter] Increment');
export const decrement = createAction('[Counter] Decrement');
export const multiply = createAction('[Counter] Multiply', props<{ value: number }>());
export const divide = createAction('[Counter] Divide', props<{ value: number }>());
export const reset = createAction('[Counter] Reset');
// export const updateMessage = createAction('[Counter] Update Message',props<{message:string}>())
export const clickMessage = createAction('[Counter] Bassvalue Message',props<{message:string}>())