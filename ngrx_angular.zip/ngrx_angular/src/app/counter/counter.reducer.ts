import { createReducer, on } from '@ngrx/store';
import * as action from './counter.actions';
import { state } from '@angular/animations';

export interface CounterState{
  value:number,
  message:string
}
const initialState:CounterState={value:0,message:''}
export const counterReducer = createReducer(
    initialState,
    on(action.increment, (state) => ({...state,value:state.value + 1})),
     on(action.decrement, (state) => ({...state,value:state.value - 1})),
    // on(action.multiply, (state, { value }) => state * value),
    // on(action.divide, (state, { value }) => state / value),
    // on(action.reset, (state) => initialState)
    // on(action.updateMessage,(state,{message})=>({...state,message})),
    on(action.clickMessage,(state,{message})=>({...state,message}))
);